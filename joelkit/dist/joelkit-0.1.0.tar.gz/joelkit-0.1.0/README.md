# JoelKit

Install with `pip install joelkit`

* Data structures
    * 
* Algorithms

